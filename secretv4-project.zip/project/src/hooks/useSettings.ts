import { useEffect, useState, useCallback } from 'react';
import { themes, defaultTheme, type Theme } from '@/data/themes';

export interface Settings {
  themeId: string;
  aboutBlankCloaking: boolean;
  closeWarning: boolean;
}

const STORAGE_KEY = 'secretv4-settings';

const defaultSettings: Settings = {
  themeId: 'cyber',
  aboutBlankCloaking: true,
  closeWarning: true,
};

function loadSettings(): Settings {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      return { ...defaultSettings, ...JSON.parse(raw) };
    }
  } catch {
    // ignore
  }
  return defaultSettings;
}

export function useSettings() {
  const [settings, setSettings] = useState<Settings>(loadSettings);

  const update = useCallback((patch: Partial<Settings>) => {
    setSettings((prev) => {
      const next = { ...prev, ...patch };
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
      } catch {
        // ignore
      }
      return next;
    });
  }, []);

  const theme: Theme = themes.find((t) => t.id === settings.themeId) ?? defaultTheme;

  useEffect(() => {
    const c = theme.colors;
    const root = document.documentElement;
    root.style.setProperty('--bg', c.bg);
    root.style.setProperty('--bg-secondary', c.bgSecondary);
    root.style.setProperty('--bg-tertiary', c.bgTertiary);
    root.style.setProperty('--panel', c.panel);
    root.style.setProperty('--border', c.border);
    root.style.setProperty('--text', c.text);
    root.style.setProperty('--text-dim', c.textDim);
    root.style.setProperty('--accent', c.accent);
    root.style.setProperty('--accent-glow', c.accentGlow);
    root.style.setProperty('--accent-secondary', c.accentSecondary);
  }, [theme]);

  return { settings, update, theme };
}
