import { useEffect, useState } from 'react';
import { Wrench, ExternalLink, Clock, Calculator, FileText, Sparkles } from 'lucide-react';
import { SubTabs, type SubTab } from '@/components/SubTabs';
import { UsefulTools } from '@/components/tools/UsefulTools';

type ToolsSection = 'tools' | 'useful';

const sections: SubTab<ToolsSection>[] = [
  { id: 'tools', label: 'Tools', icon: Wrench },
  { id: 'useful', label: 'Useful Tools', icon: Sparkles },
];

interface Tool {
  name: string;
  description: string;
  icon: typeof Wrench;
  action: () => void;
}

export function ToolsTab() {
  const [clockVisible, setClockVisible] = useState(false);
  const [section, setSection] = useState<ToolsSection>('tools');

  const tools: Tool[] = [
    {
      name: 'Fullscreen',
      description: 'Toggle fullscreen mode',
      icon: ExternalLink,
      action: () => {
        if (document.fullscreenElement) {
          document.exitFullscreen();
        } else {
          document.documentElement.requestFullscreen?.();
        }
      },
    },
    {
      name: 'Clock',
      description: 'Toggle a live clock overlay',
      icon: Clock,
      action: () => setClockVisible((v) => !v),
    },
    {
      name: 'Calculator',
      description: 'Open Google Calculator in new tab',
      icon: Calculator,
      action: () => window.open('https://www.google.com/search?q=calculator', '_blank'),
    },
    {
      name: 'Notepad',
      description: 'Open a simple notepad in new tab',
      icon: FileText,
      action: () => {
        const w = window.open('about:blank', '_blank');
        if (w) {
          w.document.write(`<!DOCTYPE html><html><head><title>Notepad</title><style>body{margin:0;background:#1a1a1a;color:#e0e0e0;font-family:monospace}textarea{width:100vw;height:100vh;border:none;outline:none;background:#1a1a1a;color:#e0e0e0;font-size:14px;padding:20px;resize:none}</style></head><body><textarea placeholder="Start typing..." autofocus></textarea></body></html>`);
          w.document.close();
        }
      },
    },
  ];

  return (
    <div className="h-full flex flex-col">
      <SubTabs tabs={sections} active={section} onChange={setSection} />
      {section === 'useful' ? (
        <UsefulTools />
      ) : (
      <div className="flex-1 overflow-y-auto -mr-2 pr-2">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {tools.map((tool, i) => (
            <button
              key={tool.name}
              onClick={tool.action}
              className="group rounded-xl border p-5 text-left transition-all duration-200 animate-slide-up"
              style={{
                background: 'var(--bg-secondary)',
                borderColor: 'var(--border)',
                animationDelay: `${i * 60}ms`,
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.borderColor = 'var(--accent)';
                e.currentTarget.style.boxShadow = `0 0 16px var(--accent-glow)`;
                e.currentTarget.style.transform = 'translateY(-2px)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.borderColor = 'var(--border)';
                e.currentTarget.style.boxShadow = 'none';
                e.currentTarget.style.transform = 'translateY(0)';
              }}
            >
              <div
                className="w-10 h-10 rounded-lg flex items-center justify-center mb-3"
                style={{
                  background: 'var(--bg-tertiary)',
                  border: '1px solid var(--border)',
                }}
              >
                <tool.icon size={20} style={{ color: 'var(--accent)' }} />
              </div>
              <p className="text-sm font-medium" style={{ color: 'var(--text)' }}>
                {tool.name}
              </p>
              <p className="text-xs mt-1" style={{ color: 'var(--text-dim)' }}>
                {tool.description}
              </p>
            </button>
          ))}
        </div>

        <div className="mt-6 rounded-xl border p-5" style={{ background: 'var(--bg-secondary)', borderColor: 'var(--border)' }}>
          <h3 className="text-sm font-medium mb-2" style={{ color: 'var(--text)' }}>
            Quick Links
          </h3>
          <div className="flex flex-wrap gap-2 mt-3">
            {['https://www.google.com', 'https://www.youtube.com', 'https://github.com', 'https://stackoverflow.com'].map((url) => (
              <button
                key={url}
                onClick={() => window.open(url, '_blank')}
                className="px-3 py-1.5 text-xs rounded-lg transition-all"
                style={{
                  background: 'var(--bg-tertiary)',
                  border: '1px solid var(--border)',
                  color: 'var(--text-dim)',
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.borderColor = 'var(--accent)';
                  e.currentTarget.style.color = 'var(--accent)';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.borderColor = 'var(--border)';
                  e.currentTarget.style.color = 'var(--text-dim)';
                }}
              >
                {url.replace('https://www.', '').replace('https://', '')}
              </button>
            ))}
          </div>
        </div>
      </div>
      )}

      {clockVisible && (
        <div
          className="fixed bottom-20 right-6 z-50 rounded-xl border p-4 animate-slide-up"
          style={{
            background: 'var(--panel)',
            borderColor: 'var(--accent)',
            boxShadow: `0 0 20px var(--accent-glow)`,
          }}
        >
          <ClockDisplay />
        </div>
      )}
    </div>
  );
}

function ClockDisplay() {
  const [time, setTime] = useState(new Date());
  useEffect(() => {
    const interval = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(interval);
  }, []);
  return (
    <div className="text-center">
      <p className="text-2xl font-mono font-bold" style={{ color: 'var(--accent)' }}>
        {time.toLocaleTimeString()}
      </p>
      <p className="text-xs mt-1" style={{ color: 'var(--text-dim)' }}>
        {time.toLocaleDateString()}
      </p>
    </div>
  );
}
