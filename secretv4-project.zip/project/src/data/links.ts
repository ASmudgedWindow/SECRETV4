export interface SiteLink {
  name: string;
  url: string;
}

/** Fun things to do when you're bored (from the SECRET LEGACY doc). */
export const boredLinks: SiteLink[] = [
  { name: 'WebGL Fluid Sim', url: 'https://paveldogreat.github.io/WebGL-Fluid-Simulation/' },
  { name: 'Silk', url: 'https://weavesilk.com/' },
  { name: 'A Dark Room', url: 'https://adarkroom.github.io/' },
  { name: 'Little Alchemy', url: 'https://littlealchemy.com/' },
  { name: 'Sans Fight (bad time sim)', url: 'https://sans-simulator.github.io/c2-sans-fight/' },
  { name: 'Blocks Game/Puzzle', url: 'https://blocks.ovh/' },
  { name: 'Speed', url: 'https://neal.fun/speed/' },
  { name: 'Procatinator', url: 'https://procatinator.com/?cat=99' },
  { name: 'Infinite Zoom', url: 'https://zoomquilt.org/' },
  { name: 'Another Infinite Zoom', url: 'https://infiniteflowers.net/' },
  { name: 'ClickClickClick', url: 'https://clickclickclick.click/' },
  { name: 'Eel Slap', url: 'https://eelslap.com/' },
  { name: 'Leapfrog Game/Puzzle', url: 'https://toms.toys/toy/leapfrog' },
  { name: 'Scale of the Universe', url: 'https://scaleofuniverse.com/en' },
  { name: 'Long Doge Challenge', url: 'https://longdogechallenge.com/' },
  { name: 'Cursor Effects', url: 'https://cursoreffects.com/' },
  { name: 'Koalas To The Max', url: 'https://www.koalastothemax.com/' },
  { name: 'ThisIsSand', url: 'https://thisissand.com/' },
];

/** Handy sites (from the SECRET LEGACY doc). */
export const usefulLinks: SiteLink[] = [
  { name: 'Invisible Character', url: 'https://www.ilovenote.net/tool/invisible-character' },
  { name: 'YT Video Downloader', url: 'https://turboscribe.ai/downloader/youtube/video' },
  { name: 'TinyURL (Link Shortener)', url: 'https://tinyurl.com/' },
  { name: 'RemoveBG', url: 'https://www.remove.bg/' },
  { name: 'Lucide (Free Icons)', url: 'https://lucide.dev/' },
  { name: 'Universal File Converter', url: 'https://p2r3.github.io/convert/' },
  { name: 'Simpletools.lol', url: 'https://simpletools.lol/' },
  { name: 'Text Emojis and More', url: 'https://emojidb.org/all-emojis' },
];
