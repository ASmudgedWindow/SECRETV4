import { useState, useCallback } from 'react';
import { Cloaker } from '@/components/Cloaker';
import { Intro } from '@/components/Intro';
import { AppShell } from '@/components/AppShell';
import { useSettings } from '@/hooks/useSettings';

type Phase = 'cloaking' | 'intro' | 'ready';

function App() {
  const [phase, setPhase] = useState<Phase>('cloaking');
  const { settings } = useSettings();

  const handleCloakReady = useCallback(() => {
    setPhase('intro');
  }, []);

  const handleIntroComplete = useCallback(() => {
    setPhase('ready');
  }, []);

  // If we're inside the cloaked iframe (URL has #cloaked), skip cloaking
  const isCloakedFrame = window.location.hash === '#cloaked';

  if (!isCloakedFrame && phase === 'cloaking') {
    return <Cloaker onCloakReady={handleCloakReady} enabled={settings.aboutBlankCloaking} />;
  }

  if (phase === 'cloaking') {
    // We're in the iframe, go straight to intro
    return <Cloaker onCloakReady={handleCloakReady} enabled={false} />;
  }

  if (phase === 'intro') {
    return <Intro onComplete={handleIntroComplete} />;
  }

  return (
    <>
      <div className="scan-overlay" />
      <AppShell />
    </>
  );
}

export default App;
